# Week 3 Lab Exercise 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/glasgowmastersjoseph/pen/PwYVYxp](https://codepen.io/glasgowmastersjoseph/pen/PwYVYxp).

