# Week 3 Lab Exercise 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/glasgowmastersjoseph/pen/wBwNvKy](https://codepen.io/glasgowmastersjoseph/pen/wBwNvKy).

