# Week 3 Lab Exercise 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/glasgowmastersjoseph/pen/NPKoPaW](https://codepen.io/glasgowmastersjoseph/pen/NPKoPaW).

